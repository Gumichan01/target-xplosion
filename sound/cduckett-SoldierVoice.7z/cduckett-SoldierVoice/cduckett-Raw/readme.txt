Voice Artist: Charlotte Duckett <https://catalog.librivox.org/people_public.php?peopleid=7315>

Voice Recordings Copyright 2012 Charlotte Duckett <https://catalog.librivox.org/people_public.php?peopleid=7315>

License: GPLv2 or later and/or CC-BY 3.0 or later (dual licensed)

About:
These sounds were provided by Charlotte Duckett to Iwan Gabovitch via email as a reply to a forum thread requesting voice samples for Bos Wars <http://www.boswars.org/> on Librivox forums: https://forum.librivox.org/viewtopic.php?f=22&t=42984 . Permission to use under CC-BY 3.0 or later or GPLv2 or later and specifically to upload to http://opengameart.org were given via email.

Please write a comment on http://opengameart.org to let the community know where you use these sounds!

Have fun making games!
