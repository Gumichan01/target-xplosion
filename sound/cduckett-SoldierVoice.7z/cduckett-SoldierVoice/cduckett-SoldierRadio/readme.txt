Voice Artist: Charlotte Duckett <https://catalog.librivox.org/people_public.php?peopleid=7315>
Editor: Iwan Gabovitch <http://qubodup.net>

Voice Recordings Copyright 2012 Charlotte Duckett <https://catalog.librivox.org/people_public.php?peopleid=7315>
Editing Copyright 2012 Iwan Gabovitch  <http://qubodup.net>

License: GPLv2 or later and/or CC-BY 3.0 or later (dual licensed)

Processing:
1. Pitch down (if I remember correctly: -2 semitones)
2. Cutting of samples.
3. Noise removal
4. Normalization to -0.01dB
5. Fade in/out at start/end of tracks for click removal
