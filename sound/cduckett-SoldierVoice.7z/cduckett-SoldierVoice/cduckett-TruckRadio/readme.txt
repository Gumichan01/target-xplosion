Voice Artist: Charlotte Duckett <https://catalog.librivox.org/people_public.php?peopleid=7315>
Editor: Iwan Gabovitch <http://qubodup.net>

Voice Recordings Copyright 2012 Charlotte Duckett <https://catalog.librivox.org/people_public.php?peopleid=7315>
Editing Copyright 2012 Iwan Gabovitch  <http://qubodup.net>

License: GPLv2 or later and/or CC-BY 3.0 or later (dual licensed

Processing:
1. Same as SoldierRadio/
2. Mixing with http://freesound.org/people/qubodup/sounds/160357/ (public domain, for vehicle background noise).
3. Mixing with http://freesound.org/people/qubodup/sounds/67522/ (public domain, for explosion/death sound).
